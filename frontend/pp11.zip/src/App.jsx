import React, { useState, useEffect } from 'react';
import { initializeApp } from 'firebase/app';
import {
  getAuth,
  signInAnonymously,
  onAuthStateChanged,
  signInWithCustomToken
} from 'firebase/auth';
import {
  getFirestore,
  collection,
  addDoc,
  deleteDoc,
  doc,
  onSnapshot,
  serverTimestamp,
  writeBatch
} from 'firebase/firestore';
import {
  ShieldAlert,
  CheckCircle2,
  Trash2,
  LayoutDashboard,
  ShoppingBag,
  Star,
  AlertTriangle,
  RefreshCw,
  Server,
  Cpu,
  Settings,
  WifiOff,
  Activity,
  Users,
  Info,
  Zap,
  Lock,
  Search
} from 'lucide-react';
import { firebaseConfig, appId, initialAuthToken } from './firebase-config';

// --- 1. Firebase Configuration ---
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// --- 2. Logic & Seed Data ---
const analyzeReviewHeuristic = (text, rating) => {
  let score = 0;
  let reasons = [];
  const lowerText = text.toLowerCase();

  if (text.length < 10) { score += 20; reasons.push("Too short"); }
  const spamKeywords = ['free', 'money', 'guarantee', 'click', 'winner', 'prize', '100%', 'crypto', 'buy now', 'link in bio'];
  const matches = spamKeywords.filter(word => lowerText.includes(word));
  if (matches.length > 0) {
    score += matches.length * 20;
    reasons.push(`Spam keywords: ${matches.join(', ')}`);
  }
  if (text === text.toUpperCase() && text.length > 10) { score += 30; reasons.push("All CAPS"); }
  if (/(.)\1{3,}/.test(text)) { score += 15; reasons.push("Repeated characters"); }

  return {
    isFlagged: score >= 40,
    confidence: Math.min(score, 100),
    reasons: reasons,
    method: 'Local Logic'
  };
};

const SEED_PRODUCTS = [
  { id: 'p1', name: 'NeuralNet GPU 4090', price: 135000, image: '🎮', description: 'Next-gen AI training architecture.' },
  { id: 'p2', name: 'Quantum Noise Earbuds', price: 16500, image: '🎧', description: 'Active reality filtering.' },
  { id: 'p3', name: 'CyberDeck Mechanical', price: 12000, image: '⌨️', description: 'Haptic feedback macros.' },
  { id: 'p4', name: 'Smart Home Hub', price: 7500, image: '🏠', description: 'Voice control your life.' }
];

// --- 3. UI Components ---

const Navbar = ({ viewMode, setViewMode }) => (
  <nav className="fixed top-4 left-1/2 -translate-x-1/2 w-[95%] max-w-4xl glass-panel rounded-full z-50 px-2 py-2 flex justify-between items-center transition-all duration-300">
    <div className="flex items-center gap-3 pl-4">
      <div className="bg-emerald-500/10 p-2 rounded-full border border-emerald-500/20">
        <ShieldAlert className="text-emerald-400" size={20} />
      </div>
      <div className="flex flex-col">
        <span className="text-lg font-bold tracking-tight bg-gradient-to-r from-white to-slate-400 bg-clip-text text-transparent hidden sm:block leading-none">
          FakeShield AI
        </span>
        <span className="text-[10px] text-emerald-500 font-medium tracking-wider hidden sm:block">
          BY GROUP 11 • RERF
        </span>
      </div>
    </div>

    <div className="flex space-x-1 bg-slate-950/50 p-1 rounded-full border border-slate-800">
      {[
        { id: 'customer', icon: ShoppingBag, label: 'Store' },
        { id: 'admin', icon: LayoutDashboard, label: 'Admin' },
        { id: 'about', icon: Info, label: 'About' }
      ].map((item) => (
        <button
          key={item.id}
          onClick={() => setViewMode(item.id)}
          className={`
            px-5 py-2 rounded-full flex items-center space-x-2 text-sm font-medium transition-all duration-300
            ${viewMode === item.id
              ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-500/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'}
          `}
        >
          <item.icon size={16} />
          <span className="hidden sm:inline">{item.label}</span>
        </button>
      ))}
    </div>
  </nav>
);

const ProductCard = ({ product, onSelect }) => (
  <div
    onClick={() => onSelect(product)}
    className="glass-card group relative overflow-hidden rounded-2xl p-6 cursor-pointer hover:-translate-y-1"
  >
    <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

    <div className="relative z-10">
      <div className="h-40 flex items-center justify-center bg-slate-900/50 rounded-xl mb-6 group-hover:bg-slate-800/50 transition-colors">
        <span className="text-6xl group-hover:scale-110 transition-transform duration-300 drop-shadow-2xl">
          {product.image}
        </span>
      </div>

      <h3 className="font-bold text-xl text-slate-100 mb-2">{product.name}</h3>
      <p className="text-slate-400 text-sm mb-4 leading-relaxed">{product.description}</p>

      <div className="flex justify-between items-center pt-2 border-t border-slate-700/50">
        <span className="font-mono text-emerald-400 font-bold text-lg">₹{product.price.toLocaleString('en-IN')}</span>
        <span className="text-xs font-semibold text-slate-300 bg-slate-800 px-3 py-1.5 rounded-full group-hover:bg-emerald-500 group-hover:text-white transition-colors">
          Write Review
        </span>
      </div>
    </div>
  </div>
);

const ReviewForm = ({ product, onSubmit, onCancel, isProcessing }) => {
  const [text, setText] = useState('');
  const [rating, setRating] = useState(5);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (text.trim().length === 0) return alert('Please write a review');
    onSubmit({ productId: product.id, productName: product.name, rating, text, author: 'Anonymous User' });
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 z-[60]">
      <div className="glass-panel w-full max-w-lg rounded-2xl p-8 relative animate-fade-in-up">
        <button onClick={onCancel} className="absolute top-4 right-4 text-slate-500 hover:text-white">✕</button>

        <div className="text-center mb-8">
          <div className="w-12 h-12 bg-emerald-500/10 rounded-full flex items-center justify-center mx-auto mb-3">
            <Star className="text-emerald-400" />
          </div>
          <h3 className="text-2xl font-bold bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">
            {product.name}
          </h3>
          <p className="text-slate-400 text-sm">Share your experience with the community</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="flex justify-center gap-2">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                type="button"
                onClick={() => setRating(star)}
                className="group p-1 transition-transform hover:scale-110 focus:outline-none"
              >
                <Star
                  size={32}
                  className={rating >= star ? "fill-yellow-400 text-yellow-400 drop-shadow-[0_0_8px_rgba(250,204,21,0.5)]" : "text-slate-700"}
                />
              </button>
            ))}
          </div>

          <div>
            <textarea
              required
              className="w-full bg-slate-950/50 border border-slate-700 rounded-xl p-4 min-h-[120px] focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 text-slate-200 placeholder:text-slate-600 transition-all outline-none resize-none"
              placeholder="What did you think? (Try 'FREE MONEY' to test detection)..."
              value={text}
              onChange={(e) => setText(e.target.value)}
            />
          </div>

          <button
            type="submit"
            disabled={isProcessing}
            className="w-full py-3.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl font-bold tracking-wide shadow-lg shadow-emerald-500/20 disabled:opacity-50 disabled:cursor-not-allowed transition-all active:scale-[0.98] flex justify-center items-center gap-2"
          >
            {isProcessing ? <RefreshCw className="animate-spin" /> : 'Submit Review'}
          </button>
        </form>
      </div>
    </div>
  );
};

// --- 4. Main Pages ---

const SettingsPanel = ({ useML, setUseML, apiEndpoint, setApiEndpoint }) => (
  <div className="glass-panel rounded-2xl p-8 mb-8">
    <div className="flex items-center gap-3 mb-6">
      <div className="p-2 bg-indigo-500/20 rounded-lg">
        <Settings className="text-indigo-400" />
      </div>
      <div>
        <h3 className="text-lg font-bold text-white">Detection Engine</h3>
        <p className="text-xs text-slate-400">Configure processing pipeline</p>
      </div>
    </div>

    <div className="grid md:grid-cols-2 gap-8">
      <div className="space-y-4">
        <label className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl border border-slate-700/50 cursor-pointer hover:border-slate-600 transition-colors">
          <div>
            <p className="font-semibold text-slate-200">Python ML Backend</p>
            <p className="text-xs text-slate-400 mt-0.5">Connect to Flask server for advanced inference</p>
          </div>
          <div className={`relative w-12 h-6 rounded-full transition-colors duration-300 ${useML ? 'bg-emerald-500' : 'bg-slate-600'}`}>
            <div className={`absolute top-1 left-1 bg-white w-4 h-4 rounded-full transition-transform duration-300 ${useML ? 'translate-x-6' : 'translate-x-0'}`} />
            <input type="checkbox" className="hidden" checked={useML} onChange={() => setUseML(!useML)} />
          </div>
        </label>

        <div className="flex items-center gap-3 px-4 py-3 bg-slate-900/50 rounded-xl border border-slate-800 text-sm font-mono text-slate-400">
          {useML ? <Cpu className="text-emerald-400" size={16} /> : <Server className="text-blue-400" size={16} />}
          <span className="flex-1">{useML ? 'Model: NaiveBayes/Sklearn' : 'Model: Local Heuristics'}</span>
          <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
        </div>
      </div>

      <div className={`space-y-2 transition-opacity duration-300 ${useML ? 'opacity-100' : 'opacity-30 pointer-events-none'}`}>
        <label className="block text-sm font-medium text-slate-300">API Endpoint</label>
        <div className="relative">
          <input
            type="text"
            value={apiEndpoint}
            onChange={(e) => setApiEndpoint(e.target.value)}
            className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-10 pr-4 py-2.5 text-sm font-mono text-slate-300 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none"
          />
          <Activity className="absolute left-3 top-2.5 text-slate-600" size={16} />
        </div>
        <p className="text-xs text-amber-500/80 flex items-center gap-1.5 mt-2">
          <WifiOff size={12} /> Auto-fallback enabled if unreachable
        </p>
      </div>
    </div>
  </div>
);

const AboutPage = () => (
  <div className="max-w-4xl mx-auto space-y-8 py-12 animate-fade-in-up">
    {/* Header */}
    <div className="text-center space-y-4 mb-12">
      <div className="inline-flex p-4 rounded-full bg-gradient-to-br from-emerald-500/20 to-cyan-500/20 border border-white/5 mb-4">
        <span className="text-5xl">🛡️</span>
      </div>
      <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight bg-gradient-to-b from-white to-slate-400 bg-clip-text text-transparent">
        FakeShield AI
      </h1>
      <h2 className="text-2xl font-bold text-emerald-400">By Group 11</h2>
      <p className="text-xl text-slate-400">Ecommerce Fake Review Detection System</p>
    </div>

    {/* Info Grid */}
    <div className="grid md:grid-cols-2 gap-6">
      <div className="glass-panel p-6 rounded-2xl border-l-4 border-emerald-500">
        <h2 className="text-xl font-bold text-white mb-4">About This Project</h2>
        <p className="text-slate-300 leading-relaxed text-sm">
          FakeShield AI is a comprehensive full-stack application designed to detect fake product reviews in ecommerce platforms using machine learning and heuristic analysis. It features a beautiful React frontend, Python ML backend, and Firebase real-time database.
        </p>
      </div>

      <div className="glass-panel p-6 rounded-2xl border-l-4 border-cyan-500">
        <h2 className="text-xl font-bold text-white mb-4">Technologies Used</h2>
        <ul className="space-y-3 text-slate-300 text-sm">
          <li className="flex items-center gap-2"><CheckCircle2 size={16} className="text-cyan-400" /> React + Vite</li>
          <li className="flex items-center gap-2"><CheckCircle2 size={16} className="text-cyan-400" /> Firebase Firestore</li>
          <li className="flex items-center gap-2"><CheckCircle2 size={16} className="text-cyan-400" /> Python Flask + Scikit-learn</li>
          <li className="flex items-center gap-2"><CheckCircle2 size={16} className="text-cyan-400" /> Tailwind CSS</li>
          <li className="flex items-center gap-2"><CheckCircle2 size={16} className="text-cyan-400" /> Naive Bayes ML Model</li>
        </ul>
      </div>
    </div>

    {/* Team Session */}
    <div className="glass-panel p-8 rounded-2xl">
      <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-3">
        <Users className="text-indigo-400" /> Development Team
      </h2>

      <div className="grid md:grid-cols-2 gap-8">
        <div>
          <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-500 mb-4">Developers</h3>
          <ul className="space-y-3">
            {["Anik Chakraborty", "Partha Basak", "MD Parvej Molla", "MD. Moontahe Maksuf Ali"].map(name => (
              <li key={name} className="flex items-center gap-2 text-slate-300">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> {name}
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-500 mb-4">Guidance</h3>
          <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700">
            <span className="text-slate-400 text-sm">Under the Guidance of:</span>
            <p className="font-bold text-white text-lg mt-1">Mr. Brijesh Kumar Choudhury</p>
          </div>
        </div>
      </div>
    </div>

    {/* Features */}
    <div className="mt-8 p-6 glass-card rounded-2xl border border-slate-800">
      <h3 className="font-bold text-lg text-white mb-4">Features</h3>
      <div className="grid md:grid-cols-2 gap-4 text-sm text-slate-300">
        <div>
          <p className="font-semibold text-emerald-400 mb-1">🎯 Dual Detection Engine</p>
          <p>Local browser logic + Python ML model</p>
        </div>
        <div>
          <p className="font-semibold text-emerald-400 mb-1">🔥 Real-Time Sync</p>
          <p>Firebase Firestore instant updates</p>
        </div>
        <div>
          <p className="font-semibold text-emerald-400 mb-1">🤖 Machine Learning</p>
          <p>Naive Bayes classifier with TF-IDF</p>
        </div>
        <div>
          <p className="font-semibold text-emerald-400 mb-1">📊 Analytics</p>
          <p>Confidence scores & flagged reasons</p>
        </div>
      </div>
    </div>

    <div className="text-center text-sm text-slate-600 pt-6">
      <p>© 2025 FakeShield AI. All rights reserved.</p>
    </div>
  </div>
);

// --- 5. Main App Component ---

export default function App() {
  const [user, setUser] = useState(null);
  const [viewMode, setViewMode] = useState('customer');
  const [products, setProducts] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [processing, setProcessing] = useState(false);
  const [useML, setUseML] = useState(false);
  const [apiEndpoint, setApiEndpoint] = useState('http://localhost:5000/predict');

  useEffect(() => {
    const initAuth = async () => {
      if (initialAuthToken) await signInWithCustomToken(auth, initialAuthToken);
      else await signInAnonymously(auth);
    };
    initAuth();
    onAuthStateChanged(auth, setUser);
  }, []);

  useEffect(() => {
    if (!user) return;
    const unsubProd = onSnapshot(collection(db, 'artifacts', appId, 'public', 'data', 'products'), (s) => {
      const p = s.docs.map(d => ({ id: d.id, ...d.data() }));
      p.length === 0 ? seedData() : setProducts(p);
    });
    const unsubRev = onSnapshot(collection(db, 'artifacts', appId, 'public', 'data', 'reviews'), (s) => {
      setReviews(s.docs.map(d => ({ id: d.id, ...d.data() })).sort((a, b) => (b.createdAt?.toMillis() || 0) - (a.createdAt?.toMillis() || 0)));
    });
    return () => { unsubProd(); unsubRev(); };
  }, [user]);

  const seedData = async () => {
    const batch = writeBatch(db);
    SEED_PRODUCTS.forEach(p => batch.set(doc(db, 'artifacts', appId, 'public', 'data', 'products', p.id), p));
    await batch.commit();
  };

  const handleReviewSubmit = async (reviewData) => {
    setProcessing(true);
    let analysis = {};
    if (useML) {
      try {
        const response = await fetch(apiEndpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: reviewData.text })
        });
        if (!response.ok) throw new Error('Unreachable');
        const data = await response.json();
        analysis = {
          isFlagged: data.isFlagged,
          confidence: data.confidence,
          reasons: data.isFlagged ? ['Flagged by Machine Learning Model'] : ['Verified by Machine Learning Model'],
          method: 'Python Model (Naive Bayes)'
        };
      } catch (err) {
        analysis = { ...analyzeReviewHeuristic(reviewData.text, reviewData.rating), method: 'Fallback Local' };
        analysis.reasons.push("Server Error");
      }
    } else {
      await new Promise(r => setTimeout(r, 800));
      analysis = analyzeReviewHeuristic(reviewData.text, reviewData.rating);
    }

    await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'reviews'), { ...reviewData, ...analysis, createdAt: serverTimestamp() });
    setProcessing(false);
    setSelectedProduct(null);
  };

  if (!user) return (
    <div className="flex h-screen items-center justify-center bg-slate-950 text-emerald-500">
      <RefreshCw className="animate-spin mr-3" /> Initializing Secure Environment...
    </div>
  );

  return (
    <div className="min-h-screen bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-900 via-slate-950 to-black pb-20">
      <Navbar viewMode={viewMode} setViewMode={setViewMode} />

      <main className="max-w-7xl mx-auto pt-24 px-4 md:px-8 animate-fade-in-up">
        {viewMode === 'customer' ? (
          <div className="space-y-10">
            <header className="text-center space-y-3 py-8">
              <h2 className="text-3xl md:text-5xl font-bold text-white tracking-tight">
                Latest <span className="bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">Tech Drops</span>
              </h2>
              <p className="text-slate-400">Authentic reviews protected by AI.</p>
            </header>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {products.map(p => <ProductCard key={p.id} product={p} onSelect={setSelectedProduct} />)}
            </div>
          </div>
        ) : viewMode === 'about' ? (
          <AboutPage />
        ) : (
          <div className="max-w-5xl mx-auto">
            <SettingsPanel useML={useML} setUseML={setUseML} apiEndpoint={apiEndpoint} setApiEndpoint={setApiEndpoint} />

            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                <Activity className="text-emerald-500" /> Live Monitor
              </h2>
              <span className="text-xs font-mono text-slate-500 bg-slate-900/50 px-3 py-1 rounded-full border border-slate-800">
                Processing {reviews.length} vectors
              </span>
            </div>

            <div className="space-y-4">
              {reviews.length === 0 && (
                <div className="flex flex-col items-center justify-center p-12 border-2 border-dashed border-slate-800 rounded-2xl text-slate-500">
                  <Search size={32} className="mb-4 opacity-50" />
                  <p>Stream empty. Waiting for data packets...</p>
                </div>
              )}

              {reviews.map(r => (
                <div key={r.id} className={`glass-panel p-5 rounded-xl border-l-4 relative overflow-hidden group hover:bg-slate-800/60 transition-colors ${r.isFlagged ? 'border-red-500/80' : 'border-emerald-500/80'}`}>
                  <div className={`absolute top-0 right-0 p-2 opacity-5 scale-150 transform rotate-12 transition-all group-hover:opacity-10`}>
                    {r.isFlagged ? <AlertTriangle size={100} /> : <CheckCircle2 size={100} />}
                  </div>

                  <div className="relative z-10 flex flex-col md:flex-row gap-6">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h4 className="font-bold text-lg text-white">{r.productName}</h4>
                        <span className="text-xs bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700">★ {r.rating}</span>
                      </div>
                      <p className="text-slate-300 text-sm leading-relaxed mb-3">"{r.text}"</p>
                      <div className="flex gap-4 text-xs text-slate-500 font-mono">
                        <span>User: {r.author}</span>
                        <span>Method: {r.method}</span>
                      </div>
                    </div>

                    <div className="flex flex-col items-end gap-3 min-w-[140px]">
                      {r.isFlagged ? (
                        <div className="text-right">
                          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-500/10 text-red-400 border border-red-500/20 text-xs font-bold">
                            <AlertTriangle size={12} /> FAKE
                          </span>
                          <span className="block text-xs text-red-400/70 mt-1 font-mono">{r.confidence}% Conf.</span>
                        </div>
                      ) : (
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-bold">
                          <CheckCircle2 size={12} /> PASS
                        </span>
                      )}

                      <button
                        onClick={() => deleteDoc(doc(db, 'artifacts', appId, 'public', 'data', 'reviews', r.id))}
                        className="p-2 text-slate-500 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-all"
                        title="Delete review"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>

                  {r.isFlagged && r.reasons?.length > 0 && (
                    <div className="mt-4 pt-3 border-t border-slate-800/50">
                      <p className="text-xs font-bold text-red-400 mb-1">Detection Reasoning:</p>
                      <div className="flex flex-wrap gap-2">
                        {r.reasons.map((reason, i) => (
                          <span key={i} className="text-[10px] bg-red-500/5 border border-red-500/10 text-red-300 px-2 py-0.5 rounded">
                            {reason}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      {selectedProduct && <ReviewForm product={selectedProduct} onSubmit={handleReviewSubmit} onCancel={() => setSelectedProduct(null)} isProcessing={processing} />}
    </div>
  );
}
